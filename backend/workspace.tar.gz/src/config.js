export const
  SECRET_KEY = process.env.SECRETKEY,
  TG_TOKEN = process.env.TGTOKEN,
  GROUP_CHATID = Number(process.env.GROUPCHATID),
  DBPATH = process.env.DBPATH 
