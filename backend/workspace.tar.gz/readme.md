# Commands
## run demo
```
npm run demo
``` 

## publish image to fandogh
```
npm run image VERSION
``` 

## deploy
set version name in fandogh.yml file and 
```
npm run deploy
```